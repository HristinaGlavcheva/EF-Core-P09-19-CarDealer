﻿
using Newtonsoft.Json;
using System.Collections.Generic;

namespace CarDealer.DTO.CarWithParts
{
    public class CarWithPartsDTO
    {
        [JsonProperty("car")]
        public Car1DTO Car1DTO { get; set; }

        [JsonProperty("parts")]
        public List<CarPartDTO> CarPartDTO { get; set; }
    }
}
