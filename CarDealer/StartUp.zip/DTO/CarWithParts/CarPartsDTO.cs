﻿namespace CarDealer.DTO.CarWithParts
{
    public class CarPartDTO
    {
        public string Name { get; set; }

        public string Price { get; set; }
    }
}
