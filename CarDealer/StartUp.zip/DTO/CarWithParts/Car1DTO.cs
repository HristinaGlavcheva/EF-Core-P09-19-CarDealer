﻿
namespace CarDealer.DTO.CarWithParts
{
    public class Car1DTO
    {
        public string Make { get; set; }

        public string Model { get; set; }

        public long TravelledDistance { get; set; }
    }
}
